<?php
$con=mysqli_connect('localhost','root','','contact_us');
?>